package examples.calculator;

public interface Loggable {
    void saveLog(String str);
}
