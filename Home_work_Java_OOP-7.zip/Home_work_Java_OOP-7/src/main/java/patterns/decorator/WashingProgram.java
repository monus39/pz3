package patterns.decorator;

public interface WashingProgram {

  void executeProgram();
}