package patterns.adapter;

public interface DataObject {

  double getValue(String fieldName);
}