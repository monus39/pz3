package patterns.factory;

import java.awt.Point;

public class Line implements Figure {

  public Line(Point x, Point y) {

  }

  @Override
  public double calculatePerimeter() {
    return 0;
  }

  @Override
  public double calculateSquare() {
    return 0;
  }

  @Override
  public double getWidth() {
    return 0;
  }

  @Override
  public double getHeight() {
    return 0;
  }
}
